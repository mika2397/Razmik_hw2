package com.example.razmik_hw2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Button

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val conversionButtonFinal = findViewById<Button>(R.id.ConvertButton)
        val addHWButtonFinal = findViewById<Button>(R.id.AddButton)
        val resetHWButton = findViewById<Button>(R.id.ResetButton)
        val homeworks: MutableList<Int?> = mutableListOf()
        var counter = 1
        var homeWorkNumericGrade = 0

        addHWButtonFinal.setOnClickListener {
            val homeworkToAdd = findViewById<EditText>(R.id.HWInput)
            val homeworkGrade = getResultOfEditText(homeworkToAdd)
            if(counter < 6) {
                if (homeworkGrade!! != null) {
                    addGradeToHWList(counter, homeworkGrade)
                    homeWorkNumericGrade += homeworkGrade
                    homeworks.add(homeworkGrade)
                    homeworkToAdd.text.clear()
                    counter += 1
                }
            }
        }

        resetHWButton.setOnClickListener {
            counter = 1
            homeWorkNumericGrade = 0
            homeworks.clear()
            findViewById<TextView>(R.id.HWResults).apply {
                text = "Homeworks:"
            }
        }

        conversionButtonFinal.setOnClickListener{
            val getFP = findViewById<EditText>(R.id.FPInput)
            val finalProjectGrade = getResultOfEditText(getFP)

            val getP = findViewById<EditText>(R.id.PInput)
            val participationGrade = getResultOfEditText(getP)

            val getPres = findViewById<EditText>(R.id.PresInput)
            val presentationGrade = getResultOfEditText(getPres)

            val getM2 = findViewById<EditText>(R.id.M2Input)
            val midterm2Grade = getResultOfEditText(getM2)

            val getM1 = findViewById<EditText>(R.id.M1Input)
            val midterm1Grade = getResultOfEditText(getM1)


            val resultToReturn = ((0.1 * participationGrade!!) + ((0.2*(homeWorkNumericGrade!!/500))*100)
                    +(0.1*presentationGrade!!) + (0.1*midterm1Grade!!) + (0.2*midterm2Grade!!)
                    +(0.3*finalProjectGrade!!))

            findViewById<TextView>(R.id.ResultText).apply{
                text = resultToReturn.toString()
            }
        }

    }
    fun getResultOfEditText(a: EditText): Int? {
        return a.text.toString().toIntOrNull()
    }

    fun addGradeToHWList(c: Int, grade:Int?): Unit{
        val stringToAdd = findViewById<TextView>(R.id.HWResults)
        stringToAdd.append("\n Homework $c: $grade ")
    }


}